# Power BI dashboard specification

Build this in Power BI Desktop (Windows) from the CSVs in `outputs/powerbi/` and `outputs/`. Save the file as `powerbi/ireland_property.pbix` and export screenshots to `figures/powerbi_*.png` for the README.

## 1. Load the data

Get Data > Text/CSV, then load:

| File | Table name | Role |
| --- | --- | --- |
| `outputs/powerbi/fact_sale.csv` | fact_sale | fact table, one row per sale |
| `outputs/powerbi/dim_county.csv` | dim_county | county and province |
| `outputs/powerbi/dim_date.csv` | dim_date | calendar |
| `outputs/data_quality_report.csv` | dq_report | cleaning log |
| `outputs/data_quality_checks.csv` | dq_checks | post-load checks |
| `outputs/reconciliation.csv` | reconciliation | CSV vs database totals |

In Power Query, set the types: `fact_sale[sale_date]` and `dim_date[date_key]` to Date; prices to Decimal; the flag columns (0/1) to Whole Number.

## 2. Model

- Relationships (many-to-one, single direction):
  - `fact_sale[sale_date]` to `dim_date[date_key]`
  - `fact_sale[county]` to `dim_county[county]`
- Mark `dim_date` as the date table (Table tools > Mark as date table, column `date_key`).
- Hide the key columns on the fact side.

## 3. DAX measures

Create a `_Measures` table (Enter Data, one dummy column) and add:

```DAX
Market Sales =
CALCULATE ( COUNTROWS ( fact_sale ), fact_sale[in_market_analysis] = 1 )

Median Price =
CALCULATE ( MEDIAN ( fact_sale[price_incl_vat] ), fact_sale[in_market_analysis] = 1 )

Median Price PY =
CALCULATE ( [Median Price], SAMEPERIODLASTYEAR ( dim_date[date_key] ) )

Median Price YoY % =
DIVIDE ( [Median Price] - [Median Price PY], [Median Price PY] )

New Home Premium % =
DIVIDE (
    CALCULATE ( [Median Price], fact_sale[property_type] = "New" ),
    CALCULATE ( [Median Price], fact_sale[property_type] = "Second-hand" )
) - 1

Share of National Sales % =
DIVIDE ( [Market Sales], CALCULATE ( [Market Sales], REMOVEFILTERS ( dim_county ) ) )

Flagged Rows =
CALCULATE ( COUNTROWS ( fact_sale ), fact_sale[in_market_analysis] = 0 )

Flagged Rows % =
DIVIDE ( [Flagged Rows], COUNTROWS ( fact_sale ) )
```

Format the percentage measures as percentages with one decimal place, and the price measures as currency (EUR, no decimals).

## 4. Pages

**Page 1: Market overview**
- Slicers: year range (`dim_date[year]`), province, property type.
- KPI cards: Market Sales, Median Price, Median Price YoY %, New Home Premium %.
- Line chart: Median Price by `dim_date[year]`, legend `fact_sale[property_type]`.
- Column chart: Market Sales by `dim_date[month_start]`.

**Page 2: Counties**
- Bar chart: Median Price by county, sorted descending.
- Bar chart: Median Price YoY % by county for the selected year (conditional formatting: red below 0, blue above).
- Table: county, province, Market Sales, Share of National Sales %, Median Price, Median Price YoY %.

**Page 3: Data quality**
- Table of `dq_report` (rule, rows affected, action).
- Table of `dq_checks` with conditional formatting: failures above 0 shown red.
- Table of `reconciliation` (measure, clean CSV, database, match).
- Cards: Flagged Rows, Flagged Rows %.

## 5. Design notes

- Keep axis labels short and leave chart titles off where the page heading already says what the chart shows.
- Use one accent colour for "New" and a neutral colour for "Second-hand" throughout.
- Note on the overview page that new-home prices include 13.5% VAT, so new and second-hand prices are comparable.
