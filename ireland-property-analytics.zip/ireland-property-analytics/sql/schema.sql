-- Star schema for the Property Price Register (SQLite).
DROP VIEW  IF EXISTS v_market_sales;
DROP TABLE IF EXISTS fact_sale;
DROP TABLE IF EXISTS dim_county;
DROP TABLE IF EXISTS dim_date;

CREATE TABLE dim_county (
    county      TEXT PRIMARY KEY,
    province    TEXT NOT NULL
);

CREATE TABLE dim_date (
    date_key    TEXT PRIMARY KEY,          -- YYYY-MM-DD
    year        INTEGER NOT NULL,
    quarter     INTEGER NOT NULL,
    month       INTEGER NOT NULL,
    month_start TEXT NOT NULL              -- YYYY-MM-01, for monthly grouping
);

CREATE TABLE fact_sale (
    sale_id                INTEGER PRIMARY KEY,
    sale_date              TEXT NOT NULL REFERENCES dim_date(date_key),
    county                 TEXT NOT NULL REFERENCES dim_county(county),
    routing_key            TEXT,
    property_type          TEXT NOT NULL CHECK (property_type IN ('New','Second-hand','Unknown')),
    price                  REAL NOT NULL CHECK (price > 0),
    vat_exclusive          INTEGER NOT NULL,
    price_incl_vat         REAL NOT NULL,
    not_full_market_price  INTEGER NOT NULL,
    price_outlier          INTEGER NOT NULL,
    in_market_analysis     INTEGER NOT NULL
);

CREATE INDEX ix_sale_county_date ON fact_sale(county, sale_date);

-- Analysis-ready view: market sales only, VAT-inclusive prices, with date attributes.
CREATE VIEW v_market_sales AS
SELECT f.sale_id, f.sale_date, d.year, d.quarter, d.month_start,
       f.county, c.province, f.property_type, f.price_incl_vat AS price
FROM fact_sale f
JOIN dim_date   d ON d.date_key = f.sale_date
JOIN dim_county c ON c.county   = f.county
WHERE f.in_market_analysis = 1;
