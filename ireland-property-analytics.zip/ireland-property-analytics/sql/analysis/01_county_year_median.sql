-- Median price and volume by county and year.
-- SQLite has no MEDIAN(), so rank prices within each group and average the middle one or two.
WITH ranked AS (
    SELECT county, province, year, price,
           ROW_NUMBER() OVER (PARTITION BY county, year ORDER BY price) AS rn,
           COUNT(*)     OVER (PARTITION BY county, year)                 AS n
    FROM v_market_sales
)
SELECT county, province, year,
       MAX(n)                AS sales,
       ROUND(AVG(price), 0)  AS median_price
FROM ranked
WHERE rn IN ((n + 1) / 2, (n + 2) / 2)
GROUP BY county, province, year
ORDER BY county, year;
