-- National median by year for new and second-hand homes, and the new-home premium.
WITH ranked AS (
    SELECT year, property_type, price,
           ROW_NUMBER() OVER (PARTITION BY year, property_type ORDER BY price) AS rn,
           COUNT(*)     OVER (PARTITION BY year, property_type)                 AS n
    FROM v_market_sales
    WHERE property_type IN ('New', 'Second-hand')
),
med AS (
    SELECT year, property_type, MAX(n) AS sales, AVG(price) AS median_price
    FROM ranked
    WHERE rn IN ((n + 1) / 2, (n + 2) / 2)
    GROUP BY year, property_type
)
SELECT year,
       MAX(CASE WHEN property_type = 'New'         THEN sales END)               AS new_sales,
       MAX(CASE WHEN property_type = 'Second-hand' THEN sales END)               AS secondhand_sales,
       ROUND(MAX(CASE WHEN property_type = 'New'         THEN median_price END), 0) AS new_median,
       ROUND(MAX(CASE WHEN property_type = 'Second-hand' THEN median_price END), 0) AS secondhand_median,
       ROUND(100.0 * (MAX(CASE WHEN property_type = 'New' THEN median_price END)
                    / MAX(CASE WHEN property_type = 'Second-hand' THEN median_price END) - 1), 1)
                                                                                  AS new_premium_pct
FROM med
GROUP BY year
ORDER BY year;
