-- Monthly national sales volume with a 3-month and 12-month rolling average.
WITH monthly AS (
    SELECT month_start, COUNT(*) AS sales
    FROM v_market_sales
    GROUP BY month_start
)
SELECT month_start, sales,
       ROUND(AVG(sales) OVER (ORDER BY month_start ROWS BETWEEN 2  PRECEDING AND CURRENT ROW), 1) AS rolling_3m,
       ROUND(AVG(sales) OVER (ORDER BY month_start ROWS BETWEEN 11 PRECEDING AND CURRENT ROW), 1) AS rolling_12m
FROM monthly
ORDER BY month_start;
