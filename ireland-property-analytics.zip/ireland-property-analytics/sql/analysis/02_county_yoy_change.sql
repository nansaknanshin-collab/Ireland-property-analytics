-- Year-on-year change in county median price, with each county's rank in each year.
WITH ranked AS (
    SELECT county, year, price,
           ROW_NUMBER() OVER (PARTITION BY county, year ORDER BY price) AS rn,
           COUNT(*)     OVER (PARTITION BY county, year)                 AS n
    FROM v_market_sales
),
med AS (
    SELECT county, year, AVG(price) AS median_price
    FROM ranked
    WHERE rn IN ((n + 1) / 2, (n + 2) / 2)
    GROUP BY county, year
)
SELECT county, year,
       ROUND(median_price, 0)                                        AS median_price,
       ROUND(LAG(median_price) OVER w, 0)                            AS prev_median,
       ROUND(100.0 * (median_price / LAG(median_price) OVER w - 1), 1) AS yoy_pct,
       RANK() OVER (PARTITION BY year ORDER BY median_price DESC)    AS price_rank
FROM med
WINDOW w AS (PARTITION BY county ORDER BY year)
ORDER BY year, price_rank;
