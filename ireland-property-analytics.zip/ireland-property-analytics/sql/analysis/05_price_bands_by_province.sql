-- Share of sales in each price band, by province, for the latest full year in the data.
WITH latest AS (
    SELECT MAX(year) AS yr FROM v_market_sales
    WHERE year < CAST(strftime('%Y', 'now') AS INTEGER)
),
banded AS (
    SELECT province,
           CASE
               WHEN price <  200000 THEN '1. under 200k'
               WHEN price <  300000 THEN '2. 200k to 300k'
               WHEN price <  400000 THEN '3. 300k to 400k'
               WHEN price <  600000 THEN '4. 400k to 600k'
               ELSE                      '5. 600k and over'
           END AS price_band
    FROM v_market_sales, latest
    WHERE year = latest.yr
)
SELECT province, price_band,
       COUNT(*) AS sales,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY province), 1) AS pct_of_province
FROM banded
GROUP BY province, price_band
ORDER BY province, price_band;
