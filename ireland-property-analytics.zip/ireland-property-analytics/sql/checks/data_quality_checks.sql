-- Each check returns one row: check name and number of failing rows (expect 0).
SELECT 'fact rows with county not in dim_county' AS check_name, COUNT(*) AS failures
FROM fact_sale f LEFT JOIN dim_county c ON c.county = f.county WHERE c.county IS NULL
UNION ALL
SELECT 'fact rows with date not in dim_date', COUNT(*)
FROM fact_sale f LEFT JOIN dim_date d ON d.date_key = f.sale_date WHERE d.date_key IS NULL
UNION ALL
SELECT 'sale dates in the future', COUNT(*)
FROM fact_sale WHERE sale_date > date('now')
UNION ALL
SELECT 'VAT-inclusive price below listed price', COUNT(*)
FROM fact_sale WHERE price_incl_vat < price
UNION ALL
SELECT 'market-analysis rows that are flagged', COUNT(*)
FROM fact_sale WHERE in_market_analysis = 1 AND (not_full_market_price = 1 OR price_outlier = 1)
UNION ALL
SELECT 'REVIEW: same date, county, price, type and routing key', COALESCE(SUM(n - 1), 0)
FROM (SELECT COUNT(*) AS n FROM fact_sale
      GROUP BY sale_date, county, price, property_type, routing_key HAVING COUNT(*) > 1);
