"""
make_sample.py

Generate a SYNTHETIC sample in the exact layout of the Property Price Register
(PPR) CSV, so the pipeline can be tested without the real download.

The numbers are invented. They reproduce the register's structure and its
known data-quality problems (euro signs and commas in prices, Irish-language
property descriptions, VAT-exclusive new homes, non-market sales, duplicate
rows, extreme values), not real market prices.

Output: data/sample/PPR-SAMPLE.csv (cp1252 encoded, like the real file)
"""

from pathlib import Path

import numpy as np
import pandas as pd

rng = np.random.default_rng(42)

# county: (base price in 2010, relative transaction volume)
COUNTIES = {
    "Dublin": (330_000, 30), "Cork": (210_000, 12), "Galway": (190_000, 6),
    "Kildare": (230_000, 6), "Meath": (215_000, 5), "Wicklow": (270_000, 4),
    "Limerick": (160_000, 5), "Wexford": (150_000, 4), "Louth": (165_000, 3),
    "Waterford": (150_000, 3), "Kerry": (165_000, 3), "Donegal": (115_000, 3),
    "Tipperary": (135_000, 3), "Clare": (155_000, 3), "Mayo": (120_000, 3),
    "Westmeath": (140_000, 2), "Kilkenny": (170_000, 2), "Sligo": (130_000, 2), "Laois": (140_000, 2), "Offaly": (125_000, 2),
    "Cavan": (115_000, 2), "Roscommon": (105_000, 1), "Carlow": (145_000, 1),
    "Monaghan": (120_000, 1), "Longford": (95_000, 1), "Leitrim": (95_000, 1),
}

# national price level by year relative to 2010 (shape only: fall, then recovery)
LEVEL = {2010: 1.00, 2011: 0.85, 2012: 0.76, 2013: 0.75, 2014: 0.86,
         2015: 0.95, 2016: 1.03, 2017: 1.13, 2018: 1.22, 2019: 1.25,
         2020: 1.26, 2021: 1.36, 2022: 1.47, 2023: 1.52, 2024: 1.62,
         2025: 1.73}
VOLUME = {2010: 0.30, 2011: 0.35, 2012: 0.48, 2013: 0.55, 2014: 0.75,
          2015: 0.85, 2016: 0.95, 2017: 1.00, 2018: 1.05, 2019: 1.05,
          2020: 0.90, 2021: 1.10, 2022: 1.15, 2023: 1.10, 2024: 1.12,
          2025: 1.10}

DESC_SECOND = ["Second-Hand Dwelling house /Apartment",
               "Teach/Árasán Cónaithe Atháimhe"]
DESC_NEW = ["New Dwelling house /Apartment", "Teach/Árasán Cónaithe Nua"]
SIZES = ["", "", "", "greater than or equal to 38 sq metres and less than 125 sq metres",
         "greater than or equal to 125 sq metres", "less than 38 sq metres"]
STREETS = ["Main Street", "Church Road", "The Green", "Park Avenue",
           "Station Road", "Oak Drive", "River View", "Hillside"]


def make(n_per_unit=6):
    rows = []
    for year, vol in VOLUME.items():
        for county, (base, weight) in COUNTIES.items():
            n = int(rng.poisson(weight * vol * n_per_unit))
            for _ in range(n):
                is_new = rng.random() < (0.08 if year < 2016 else 0.18)
                price = base * LEVEL[year] * rng.lognormal(0, 0.38)
                if is_new:
                    price *= 1.10
                vat_excl = is_new  # new homes are listed excluding 13.5% VAT
                if vat_excl:
                    price /= 1.135
                not_market = rng.random() < 0.04
                if not_market:
                    price *= rng.uniform(0.2, 0.7)
                date = pd.Timestamp(year, 1, 1) + pd.to_timedelta(
                    int(rng.integers(0, 365)), unit="D")
                desc = (rng.choice(DESC_NEW, p=[0.92, 0.08]) if is_new
                        else rng.choice(DESC_SECOND, p=[0.97, 0.03]))
                rows.append({
                    "Date of Sale (dd/mm/yyyy)": date.strftime("%d/%m/%Y"),
                    "Address": f"{rng.integers(1, 200)} {rng.choice(STREETS)}, "
                               f"Town {rng.integers(1, 40)}, Co. {county}",
                    "County": county,
                    "Eircode": "" if rng.random() < 0.7 else
                               f"{chr(65 + rng.integers(0, 20))}{rng.integers(10, 99)} "
                               f"{rng.integers(1000, 9999)}",
                    "Price (€)": f"€{price:,.2f}",
                    "Not Full Market Price": "Yes" if not_market else "No",
                    "VAT Exclusive": "Yes" if vat_excl else "No",
                    "Description of Property": desc,
                    "Property Size Description": rng.choice(SIZES) if is_new else "",
                })
    df = pd.DataFrame(rows)

    # inject known data-quality problems
    dupes = df.sample(40, random_state=1)                    # exact duplicates
    extreme = df.sample(15, random_state=2).copy()           # bulk / portfolio sales
    extreme["Price (€)"] = [f"€{v:,.2f}" for v in
                            rng.uniform(5e6, 6e7, len(extreme))]
    tiny = df.sample(10, random_state=3).copy()              # implausibly low prices
    tiny["Price (€)"] = [f"€{v:,.2f}" for v in rng.uniform(500, 4_000, len(tiny))]
    df = pd.concat([df, dupes, extreme, tiny], ignore_index=True)
    return df.sample(frac=1, random_state=4).reset_index(drop=True)


def main():
    out = Path("data/sample/PPR-SAMPLE.csv")
    out.parent.mkdir(parents=True, exist_ok=True)
    df = make()
    df.to_csv(out, index=False, encoding="cp1252")
    print(f"Wrote {len(df):,} synthetic rows to {out}")


if __name__ == "__main__":
    main()
