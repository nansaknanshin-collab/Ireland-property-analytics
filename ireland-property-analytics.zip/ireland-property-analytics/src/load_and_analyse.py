"""
load_and_analyse.py

Load the cleaned sales into a SQLite star schema, reconcile the load, run the
data-quality checks and the SQL analyses, and export Power BI inputs and figures.

Input : data/processed/sales_clean.csv
Output: data/ppr.db
        outputs/reconciliation.csv, outputs/data_quality_checks.csv
        outputs/<analysis>.csv          one per file in sql/analysis
        outputs/powerbi/fact_sale.csv, dim_county.csv, dim_date.csv
        figures/*.png
"""

import sqlite3
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

DB = Path("data/ppr.db")
SQL = Path("sql")
OUT = Path("outputs")
PBI = OUT / "powerbi"
FIG = Path("figures")

PROVINCE = {
    "Leinster": ["Carlow", "Dublin", "Kildare", "Kilkenny", "Laois", "Longford",
                 "Louth", "Meath", "Offaly", "Westmeath", "Wexford", "Wicklow"],
    "Munster": ["Clare", "Cork", "Kerry", "Limerick", "Tipperary", "Waterford"],
    "Connacht": ["Galway", "Leitrim", "Mayo", "Roscommon", "Sligo"],
    "Ulster (ROI)": ["Cavan", "Donegal", "Monaghan"],
}


def build_dims(sales):
    county = pd.DataFrame([(c, p) for p, cs in PROVINCE.items() for c in cs],
                          columns=["county", "province"])
    unknown = sorted(set(sales["county"]) - set(county["county"]))
    if unknown:
        raise ValueError(f"Counties missing from province map: {unknown}")

    days = pd.date_range(sales["sale_date"].min(), sales["sale_date"].max(), freq="D")
    date = pd.DataFrame({
        "date_key": days.strftime("%Y-%m-%d"),
        "year": days.year,
        "quarter": days.quarter,
        "month": days.month,
        "month_start": days.to_period("M").to_timestamp().strftime("%Y-%m-%d"),
    })
    return county, date


def load(con, sales, county, date):
    con.executescript((SQL / "schema.sql").read_text())
    county.to_sql("dim_county", con, if_exists="append", index=False)
    date.to_sql("dim_date", con, if_exists="append", index=False)
    s = sales.copy()
    for col in ["vat_exclusive", "not_full_market_price", "price_outlier",
                "in_market_analysis"]:
        s[col] = s[col].astype(int)
    s.to_sql("fact_sale", con, if_exists="append", index=False)
    con.commit()


def reconcile(con, sales):
    db = con.execute("""SELECT COUNT(*), ROUND(SUM(price), 2),
                               SUM(in_market_analysis) FROM fact_sale""").fetchone()
    rows = [
        ("row count", len(sales), db[0]),
        ("sum of listed price", round(sales["price"].sum(), 2), db[1]),
        ("rows in market analysis", int(sales["in_market_analysis"].sum()), db[2]),
    ]
    rec = pd.DataFrame(rows, columns=["measure", "clean_csv", "database"])
    rec["match"] = (rec["clean_csv"] - rec["database"]).abs() < 0.01
    rec.to_csv(OUT / "reconciliation.csv", index=False)
    print("\nReconciliation (clean CSV vs database):")
    print(rec.to_string(index=False, float_format=lambda v: f"{v:,.2f}"))
    if not rec["match"].all():
        raise SystemExit("Reconciliation failed.")


def run_checks(con):
    checks = pd.read_sql((SQL / "checks" / "data_quality_checks.sql").read_text(), con)
    checks.to_csv(OUT / "data_quality_checks.csv", index=False)
    print("\nData-quality checks (expect 0 unless marked REVIEW):")
    print(checks.to_string(index=False))
    hard = checks[~checks["check_name"].str.startswith("REVIEW")]
    if (hard["failures"] > 0).any():
        raise SystemExit("Data-quality checks failed.")


def run_analyses(con):
    results = {}
    for f in sorted((SQL / "analysis").glob("*.sql")):
        df = pd.read_sql(f.read_text(), con)
        df.to_csv(OUT / f"{f.stem}.csv", index=False)
        results[f.stem] = df
        print(f"  {f.stem}: {len(df)} rows")
    return results


def export_powerbi(con):
    PBI.mkdir(parents=True, exist_ok=True)
    for t in ["fact_sale", "dim_county", "dim_date"]:
        pd.read_sql(f"SELECT * FROM {t}", con).to_csv(PBI / f"{t}.csv", index=False)


def figures(r):
    FIG.mkdir(exist_ok=True)

    nv = r["03_new_vs_secondhand"]
    fig, ax = plt.subplots(figsize=(5.5, 3.5))
    ax.plot(nv["year"], nv["secondhand_median"] / 1e3, "o-", label="second-hand")
    ax.plot(nv["year"], nv["new_median"] / 1e3, "s--", label="new (incl. VAT)")
    ax.set_xlabel("Year")
    ax.set_ylabel("Median price (EUR k)")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "median_new_vs_secondhand.png", dpi=200)
    plt.close(fig)

    mv = r["04_monthly_volume_rolling"]
    x = pd.to_datetime(mv["month_start"])
    fig, ax = plt.subplots(figsize=(5.5, 3.5))
    ax.plot(x, mv["sales"], color="0.75", lw=0.8, label="monthly sales")
    ax.plot(x, mv["rolling_12m"], color="C0", lw=2, label="12-month rolling mean")
    ax.set_xlabel("Month")
    ax.set_ylabel("Sales")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "monthly_volume.png", dpi=200)
    plt.close(fig)

    # latest FULL year, so a part-year is never compared with a full year
    yoy = r["02_county_yoy_change"].dropna(subset=["yoy_pct"])
    yoy = yoy[yoy["year"] < pd.Timestamp.now().year]
    last = yoy[yoy["year"] == yoy["year"].max()].sort_values("yoy_pct")
    fig, ax = plt.subplots(figsize=(5.5, 6))
    ax.barh(last["county"], last["yoy_pct"], color="C0",
            label=f"{int(last['year'].iloc[0])} vs previous year")
    ax.axvline(0, color="k", lw=0.8)
    ax.set_xlabel("Change in median price (%)")
    ax.legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(FIG / "county_yoy_latest.png", dpi=200)
    plt.close(fig)


def main():
    OUT.mkdir(exist_ok=True)
    sales = pd.read_csv("data/processed/sales_clean.csv")
    county, date = build_dims(sales)
    DB.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB) as con:
        load(con, sales, county, date)
        reconcile(con, sales)
        run_checks(con)
        print("\nAnalyses:")
        results = run_analyses(con)
        export_powerbi(con)
    figures(results)
    print(f"\nDatabase: {DB} | CSVs: {OUT}/ | Power BI inputs: {PBI}/ | figures: {FIG}/")


if __name__ == "__main__":
    main()
