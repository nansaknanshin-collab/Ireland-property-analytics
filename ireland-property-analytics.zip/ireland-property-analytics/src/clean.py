"""
clean.py

Clean the Property Price Register (PPR) CSV and log every data-quality rule.

Input : data/raw/PPR-ALL.csv  (real download, see README)
        or data/sample/PPR-SAMPLE.csv with --sample
Output: data/processed/sales_clean.csv
        outputs/data_quality_report.csv   (rule, rows affected, action)

Design choice: implausible prices and non-market sales are FLAGGED, not deleted,
so the raw-to-clean row reconciliation stays exact and analysts can choose the
filter. Rows that cannot be parsed at all (bad dates, bad prices) and exact
duplicates are removed, and each removal is counted in the report.
"""

import argparse
import re
from pathlib import Path

import numpy as np
import pandas as pd

VAT_RATE_NEW_HOMES = 0.135
PRICE_FLOOR, PRICE_CAP = 10_000, 5_000_000   # outside this range: flagged

PROCESSED = Path("data/processed")
OUTPUTS = Path("outputs")


def read_ppr(path):
    """The PPR file is not UTF-8; try the likely encodings in turn."""
    for enc in ("utf-8", "cp1252", "latin-1"):
        try:
            return pd.read_csv(path, encoding=enc, dtype=str, keep_default_na=False)
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Could not decode {path}")


def standardise_columns(df):
    """Map PPR headers to snake_case by prefix (the price header's euro sign
    is often garbled, so exact matching is fragile)."""
    mapping = {}
    for col in df.columns:
        c = col.strip().lower()
        if c.startswith("date of sale"):
            mapping[col] = "sale_date"
        elif c.startswith("address"):
            mapping[col] = "address"
        elif c.startswith("county"):
            mapping[col] = "county"
        elif c.startswith("eircode") or c.startswith("postal code"):
            mapping[col] = "eircode"
        elif c.startswith("price"):
            mapping[col] = "price_raw"
        elif c.startswith("not full market"):
            mapping[col] = "not_full_market_price"
        elif c.startswith("vat exclusive"):
            mapping[col] = "vat_exclusive"
        elif c.startswith("description of property"):
            mapping[col] = "description"
        elif c.startswith("property size"):
            mapping[col] = "size_description"
    df = df.rename(columns=mapping)
    needed = {"sale_date", "county", "price_raw", "not_full_market_price",
              "vat_exclusive", "description"}
    missing = needed - set(df.columns)
    if missing:
        raise ValueError(f"Missing expected columns: {missing}")
    return df


def property_type(desc):
    d = desc.lower()
    if "new" in d or "nua" in d:
        return "New"
    if "second" in d or "athá" in d or "atha" in d:
        return "Second-hand"
    return "Unknown"


def parse_price(s):
    cleaned = re.sub(r"[^0-9.]", "", s)
    try:
        return float(cleaned)
    except ValueError:
        return np.nan


def clean(path):
    log = []

    def record(rule, n, action):
        log.append({"rule": rule, "rows_affected": int(n), "action": action})

    df = standardise_columns(read_ppr(path))
    record("raw rows read", len(df), "input")

    n0 = len(df)
    df = df.drop_duplicates()
    record("exact duplicate rows", n0 - len(df), "removed")

    df["sale_date"] = pd.to_datetime(df["sale_date"], format="%d/%m/%Y",
                                     errors="coerce")
    bad = df["sale_date"].isna()
    record("unparseable sale date", bad.sum(), "removed")
    df = df[~bad]

    df["price"] = df["price_raw"].map(parse_price)
    bad = df["price"].isna() | (df["price"] <= 0)
    record("unparseable or non-positive price", bad.sum(), "removed")
    df = df[~bad]

    df["county"] = df["county"].str.strip().str.title()

    df["property_type"] = df["description"].map(property_type)
    record("Irish-language property description",
           df["description"].str.contains("Teach", case=False).sum(),
           "translated to New / Second-hand")
    record("property type unknown", (df["property_type"] == "Unknown").sum(),
           "kept, labelled Unknown")

    df["vat_exclusive"] = df["vat_exclusive"].str.strip().str.lower().eq("yes")
    df["price_incl_vat"] = np.where(df["vat_exclusive"],
                                    df["price"] * (1 + VAT_RATE_NEW_HOMES),
                                    df["price"]).round(2)
    record("VAT-exclusive price", df["vat_exclusive"].sum(),
           f"VAT at {VAT_RATE_NEW_HOMES:.1%} added in price_incl_vat")

    df["not_full_market_price"] = (df["not_full_market_price"]
                                   .str.strip().str.lower().eq("yes"))
    record("not full market price", df["not_full_market_price"].sum(),
           "flagged, excluded from market analysis")

    df["price_outlier"] = ((df["price_incl_vat"] < PRICE_FLOOR) |
                           (df["price_incl_vat"] > PRICE_CAP))
    record(f"price outside EUR {PRICE_FLOOR:,} to {PRICE_CAP:,}",
           df["price_outlier"].sum(), "flagged, excluded from market analysis")

    # privacy: drop the street address; keep only the Eircode routing key
    eir = df.get("eircode", pd.Series("", index=df.index)).fillna("")
    df["routing_key"] = eir.str.strip().str[:3].str.upper().replace("", None)
    record("Eircode missing", df["routing_key"].isna().sum(), "kept, routing key null")
    record("street address", len(df), "dropped for privacy")

    df["in_market_analysis"] = ~(df["not_full_market_price"] | df["price_outlier"])
    record("rows in market analysis", df["in_market_analysis"].sum(), "output")
    record("clean rows written", len(df), "output")

    df = df.sort_values("sale_date").reset_index(drop=True)
    df.insert(0, "sale_id", np.arange(1, len(df) + 1))
    cols = ["sale_id", "sale_date", "county", "routing_key", "property_type",
            "price", "vat_exclusive", "price_incl_vat", "not_full_market_price",
            "price_outlier", "in_market_analysis"]
    return df[cols], pd.DataFrame(log)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample", action="store_true",
                    help="use the synthetic sample instead of the real file")
    args = ap.parse_args()
    src = (Path("data/sample/PPR-SAMPLE.csv") if args.sample
           else Path("data/raw/PPR-ALL.csv"))

    PROCESSED.mkdir(parents=True, exist_ok=True)
    OUTPUTS.mkdir(exist_ok=True)
    df, report = clean(src)
    df.to_csv(PROCESSED / "sales_clean.csv", index=False, date_format="%Y-%m-%d")
    report.to_csv(OUTPUTS / "data_quality_report.csv", index=False)
    print(f"Source: {src}")
    print(report.to_string(index=False))


if __name__ == "__main__":
    main()
